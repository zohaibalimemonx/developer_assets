jQuery(document).ready(function(e){




    // AJAX CALL
/*
    jQuery("#").validate();
    jQuery(document).on('submit', '#', function(e) {

		e.preventDefault();

		jQuery.LoadingOverlay("show", {
            image       : "",
            text        : "Processing..."
        });
		
        var form = jQuery(this);
		var formData = new FormData(form[0]);
		jQuery.ajax({
			type: 'post',
			url: handler_object.ajax_url+'?action=step1',
			contentType: false,
			processData: false,
			dataType: 'json',
			data: formData,
		})
		.done(function(value){
            if(value.status)
            {
        		jQuery.LoadingOverlay("hide");
        		jQuery("#ajax-content").html(value.html);
				Swal.fire({
                    icon: 'success',
                    title: 'Thank You',
                    text: 'Form has been submitted Successfully!'
                });
            }
            else
            {

            }
		});
	});
*/

});