<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'stripe/stripe-php' => 
    array (
      'pretty_version' => 'v9.0.0',
      'version' => '9.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'e405c178c2167f568e654296ad6b20eb461761b5',
    ),
  ),
);
